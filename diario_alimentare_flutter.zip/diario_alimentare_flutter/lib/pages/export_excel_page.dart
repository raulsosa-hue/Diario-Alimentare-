
import 'package:flutter/material.dart';
import '../services/storage_service.dart';
import '../services/excel_service.dart';
import '../models/entry.dart';

class ExportExcelPage extends StatefulWidget {
  const ExportExcelPage({super.key});

  @override
  State<ExportExcelPage> createState() => _ExportExcelPageState();
}

class _ExportExcelPageState extends State<ExportExcelPage> {
  final _storage = StorageService();
  final _excel = ExcelService();
  bool _isExporting = false;
  List<DiaryEntry> _entries = [];

  @override
  void initState() {
    super.initState();
    _loadEntries();
  }

  Future<void> _loadEntries() async {
    final entries = await _storage.getEntries();
    setState(() {
      _entries = entries;
    });
  }

  Future<void> _export() async {
    if (_entries.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Nessun dato da esportare')),
        );
      }
      return;
    }

    setState(() {
      _isExporting = true;
    });

    try {
      final file = await _excel.exportToCsv(_entries);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('File CSV creato: ${file.path}')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Errore durante esportazione: $e')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isExporting = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Esporta in Excel (CSV)'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Voci totali nel diario: ${_entries.length}'),
            const SizedBox(height: 8),
            const Text(
              'Premi il pulsante qui sotto per creare un file CSV apribile con Excel.
'
              'Il file verrà salvato nella cartella documenti dell'app.',
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _isExporting ? null : _export,
              icon: _isExporting
                  ? const SizedBox(
                      height: 16,
                      width: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.file_download),
              label: Text(_isExporting ? 'Esporto...' : 'Esporta CSV'),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: _entries.length,
                itemBuilder: (context, index) {
                  final e = _entries[index];
                  final date = '${e.dateTime.day.toString().padLeft(2, '0')}/'
                      '${e.dateTime.month.toString().padLeft(2, '0')}/'
                      '${e.dateTime.year}';
                  final time = '${e.dateTime.hour.toString().padLeft(2, '0')}:'
                      '${e.dateTime.minute.toString().padLeft(2, '0')}';
                  return ListTile(
                    title: Text('${e.category} • ${e.type}'),
                    subtitle: Text('$date $time  -  ${e.content}'),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
