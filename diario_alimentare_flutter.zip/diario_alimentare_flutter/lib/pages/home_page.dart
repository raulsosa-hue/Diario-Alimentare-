
import 'package:flutter/material.dart';
import 'add_meal_page.dart';
import 'add_extra_page.dart';
import 'add_exercise_page.dart';
import 'export_excel_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Diario Alimentare & Esercizio'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Cosa vuoi registrare?',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          _HomeButton(
            label: 'Pasto principale (colazione, pranzo, cena)',
            icon: Icons.restaurant,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AddMealPage()),
              );
            },
          ),
          _HomeButton(
            label: 'Pasto aggiuntivo / spuntino',
            icon: Icons.fastfood,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AddExtraPage()),
              );
            },
          ),
          _HomeButton(
            label: 'Esercizio fisico',
            icon: Icons.fitness_center,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AddExercisePage()),
              );
            },
          ),
          const SizedBox(height: 24),
          const Divider(),
          const SizedBox(height: 8),
          _HomeButton(
            label: 'Esporta diario in Excel (CSV)',
            icon: Icons.file_download,
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ExportExcelPage()),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _HomeButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;

  const _HomeButton({
    required this.label,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        leading: Icon(icon),
        title: Text(label),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
